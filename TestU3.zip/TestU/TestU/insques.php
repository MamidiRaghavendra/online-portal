<?php 

	if(isset($_POST['submit']))
	{
	session_start();
	// Include config file
	$servername = "localhost";
	$username = "id9726315_wp_505fb1e6e052602351622245fd40f636";
	$password = "raghavendra";
	$dbname = "id9726315_wp_505fb1e6e052602351622245fd40f636";
	
	$ans=$_POST['groupOfDefaultRadios'];
	$quest=$_POST['ques'];
	$des=$_POST['desc'];
	 // Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	if (!$conn) 
	{
		die("Connection failed: " . mysqli_connect_error());
	}
		
		$sql = "CREATE TABLE IF NOT EXISTS Question_Details (QUESTION_NUMBER INT(5) UNSIGNED AUTO_INCREMENT PRIMARY KEY, QUESTION VARCHAR(10000) NOT NULL, CORRECT_ANS VARCHAR(50), EXPLANATION VARCHAR(100000) NOT NULL)";
	
	if ($conn->query($sql) === TRUE)
	{
		echo "<script>
			alert('Question Table Created Successfully.');
			window.location.href='create test.php';
		
		</script>";
	}
	
	$sql = "INSERT INTO Question_Details set QUESTION = '$quest' , CORRECT_ANS = '$ans' , EXPLANATION = '$des' ";
	
	if (mysqli_query($conn, $sql)) 
	{
		echo "<script>

		alert('New record created successfully');
		window.location.href='manuallyadd.html';
		</script>";
		
	} 
	else 
	{
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}

	mysqli_close($conn);
	}
?>