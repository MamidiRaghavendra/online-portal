<?php
// Start the session
session_start();
?>
<!doctype html>
<html lang="en">

  <head>
    <title>test portal &mdash; </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=DM+Sans:300,400,700|Indie+Flower" rel="stylesheet">
    

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">
    
    
    
    <style>
     
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

/* Button used to open the contact form - fixed at the bottom of the page */
.open-button {
  background-color: orange;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  opacity: 0.8;
  position: fixed;
  bottom: 23px;
  right: 28px;
  width: 280px;
}

/* The popup form - hidden by default */
.form-popup {
  display: none;
  position: fixed;
  bottom: 0;
  right: 15px;
  border: 3px solid #f1f1f1;
  z-index: 9;
}

/* Add styles to the form container */
.form-container {
  max-width: 300px;
  padding: 10px;
  background-color: white;
}

/* Full-width input fields */
.form-container input[type=text], .form-container input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

/* When the inputs get focus, do something */
.form-container input[type=text]:focus, .form-container input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit/login button */
.form-container .btn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  margin-bottom:10px;
  opacity: 0.8;
}

/* Add a red background color to the cancel button */
.form-container .cancel {
  background-color: red;
}

/* Add some hover effects to buttons */
.form-container .btn:hover, .open-button:hover {
  opacity: 1;
}
</style>


  
  </head>

  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

    
    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>
      
      
      
      








      <header class="site-navbar site-navbar-target" role="banner">

        <div class="container mb-3">
          <div class="d-flex align-items-center">
            <div class="site-logo mr-auto">
              <a href="index.html" style="margin-left:-90px;"><img src="images/logo1.png" style="padding-left: 55px;"><span class="text-primary"></span></a>
            </div>
<!--login form button-->
            <button class="open-button" onclick="openForm()" style="font-size:20px;margin-bottom:80px;">Login</button>

<div class="form-popup" id="myForm">
  <form action="login.php" class="form-container">
    <h1>Login</h1>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>

    <button type="submit" class="btn">Login</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>
</div>

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>
<!--end of login form button-->

 <!--register form button-->
 <button class="open-button" onclick="openForm1()" style="font-size:20px;">Register</button>

 <div class="form-popup" id="myForm1">
   <form action="Register.php" class="form-container">
     <h1>Register</h1>
 
     <label for="email"><b>Email</b></label>
     <input type="text" placeholder="Enter Email"  name="email" required>
 
     <label for="psw"><b>Password</b></label>
     <input type="password" placeholder="Enter Password" name="psw" required>

     <button type="submit" class="btn">Register</button>
     <button type="button" class="btn cancel" onclick="closeForm1()">Close</button>
   </form>
 </div>
 
 <script>
 function openForm1() {
   document.getElementById("myForm1").style.display = "block";
 }
 
 function closeForm1() {
   document.getElementById("myForm1").style.display = "none";
 }
 </script>
 <!--end of register form button-->

<!--Streer name and time to open-->
            <div class="site-quick-contact d-none d-lg-flex ml-auto ">
              <div class="d-flex site-info align-items-center mr-5">
                <span class="block-icon mr-3"><span class="icon-map-marker text-yellow"></span></span>
                <span>34 Street Name, City Name Here, <br> United States</span>
              </div>
              <div class="d-flex site-info align-items-center">
                <span class="block-icon mr-3"><span class="icon-clock-o"></span></span>
                <span>24/7 Online Service<br> </span>
              </div>
              
              <div class="d-flex site-info align-items-center">
                <img src="images/login1.png" style="height:37px;width:37px;margin-left:50px;">
                <span style="font-size:19px;">Welcome,<?php echo $_SESSION["email"]; ?> <br> </span>
              </div>
              
              
            </div>
          </div>
        </div>
<!-- End of Street name and time to open-->

        <div class="container">
          <div class="menu-wrap d-flex align-items-center">
            <span class="d-inline-block d-lg-none"><a href="#" class="text-black site-menu-toggle js-menu-toggle py-5"><span class="icon-menu h3 text-black"></span></a></span>

              

              <nav class="site-navigation text-left mr-auto d-none d-lg-block" role="navigation">
                <ul class="site-menu main-menu js-clone-nav mr-auto ">
                  <li class="active"><a href="index.php" class="nav-link">Home</a></li>
                  <li><a href="" class="nav-link">About</a></li>
                  <li><a href="" class="nav-link">Packages</a></li>
                  <li><a href="" class="nav-link">Online Tests</a></li>
                  <li><a href="" class="nav-link">Pricing</a></li>
                  <li><a href="" class="nav-link">Contact</a></li>
                </ul>
              </nav>

              <div class="top-social ml-auto">
                <a href="#"><span class="icon-facebook text-teal"></span></a>
                <a href="#"><span class="icon-twitter text-success"></span></a>
                <a href="#"><span class="icon-linkedin text-yellow"></span></a>
              </div>
          </div>
        </div>

       

      </header>
    <div class="ftco-blocks-cover-1">
       
      <div class="site-section-cover overlay">
        <div class="container">
          <div class="row align-items-center ">
            <div class="col-md-5 mt-5 pt-5">
              <span class="text-cursive h5 text-red">Welcome To Our Website</span>
               
                   <h1 class="mb-3 font-weight-bold text-teal"><p style="font-size:91%" >Create your own test</p><p style="font-size:85%" >Any time & Any where</p></h1>
              <p>Amazing Website for those who want to create the test,attempt the test!!</p>
              <p class="mt-5"><a href="create test.php" class="btn btn-primary py-4 btn-custom-1">Create Test</a></p>
              <p class="mt-5"><a href="attempt test.html" class="btn btn-primary py-4 btn-custom-1" style="margin-left: 45%;
margin-bottom: -0%;
margin-top: -44.9%;">Attempt Test</a></p>
            </div>
      
            <div class="col-md-6 ml-auto align-self-end">
              <img src="images/book.png" alt="Image" class="img-fluid" style="height:640px;">
              
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="block-2 red">
              <span class="wrap-icon">
                <span class="icon-home"></span>
              </span>
             <a href="create test.php "><h2>Create Test</h2>
              <p>Create your own test in just three steps,and some content of Create Test will cme here!!!!</p></a>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="block-2 yellow">
              <span class="wrap-icon">
                <span class="icon-person"></span>
              </span>
             <a href="attempt test.html"><h2>Attempt Test</h2><p>We provide a huge Collection of tests and category for student like Online Aptitude test.
              </p></a> 
            </div>
          </div>
          <div class="col-lg-4">
            <div class="block-2 teal">
              <span class="wrap-icon">
                <span class="icon-cog"></span>
              </span>
              <a href="#"><h2>More Tests</h2>
              <p>You can attempt more test like Bank PO, PSC,,and sme content of More Tests will cme here!!!!</p></a>
            </div>
          </div>
        </div>
      </div>
    </div>


  <div class="site-section bg-light" style="margin-top:-5%">
      <div class="container">
        <div class="row">
          <div class="col-md-6 mb-5 mb-md-0">
            <img src="images/bookus1.jpg" alt="Image" class="img-fluid">
          </div>
          <div class="col-md-5 ml-auto pl-md-5">
            <span class="text-cursive h5 text-red">About Us</span>
            <h3 class="text-black">More about company</h3>
            A site for educators, TestU.com allows them to create and administer tests in a fast and reliable way. If you're one, this new platform lets you create tests using an interface that is intuitive before anything else, and that is hosted 100 % online. You don't have to install anything on your own computer. 

            <p class="mt-5"><a href="#" class="btn btn-warning py-4 btn-custom-1">More About Us</a></p>
          </div>
        </div>
      </div>
    </div>
    
    
      <div class="site-section">
      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <span class="text-cursive h5 text-red d-block">Pricing Plan</span>
            <h2 class="text-black">Our Pricing</h2>
            <p>As you can see we have three pricing plans 1.Free Plan,2.Standar Plan,3.Professional Plan Compare our plans below. Got questions? Call our sales line at +91 **********
No credit card needed. Change plans any time.</p>
          </div>
          <div class="col-md-3">
            <div class="pricing teal">
              <span class="price">
                <span>$0</span>
              </span>
              <h3>Free Plan</h3>
              <ul class="ul-check list-unstyled teal">
                <li>Getting started with Think Exam</li>  
                <li>30 test attempts / mo.</li>
             
              </ul>
              <p><a href="#" class="btn btn-teal btn-custom-1 mt-4">Buy Now</a></p>
            </div>
          </div>
          <div class="col-md-3">
            <div class="pricing danger">
              <span class="price">
                <span style="background-color:#fdb62f">$30</span>
              </span>
              <h3>Standard Plan</h3>
              <ul class="ul-check list-unstyled danger">
                <li>Great for growing business</li>  
                <li>500 test attempts / mo.</li>
            
              </ul>
              <p><a href="#" class="btn btn-danger btn-custom-1 mt-4" style="background-color:#fdb62f;margin-bottom:-30%;">Buy Now</a></p>
            </div>
          </div>
              <div class="col-md-3">
            <div class="pricing teal">
              <span class="price">
                <span>$70</span>
              </span>
              <h3>Professional Pack</h3>
              <ul class="ul-check list-unstyled teal">
                <li>Best professional solution for existing business</li>  
                <li>1,000 test attempts / mo.</li>
               
              </ul>
              <p><a href="#" class="btn btn-teal btn-custom-1 mt-4">Buy Now</a></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    