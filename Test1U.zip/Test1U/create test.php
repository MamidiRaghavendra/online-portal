<!doctype html>
<html lang="en">
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=DM+Sans:300,400,700|Indie+Flower" rel="stylesheet">
    

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/aos.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="css/style.css">

    
 
  <head>
      <style>
          
.button {
  border-radius: 4px;
  background-color: #dc3545;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 20px;
  padding: 10px;
  width: 150px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
  margin-top:20px;
 height: 55px;

margin-left: 55%;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
.button1 {
  border-radius: 4px;
  background-color: #dc3545;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 20px;
  padding: 10px;
  width: 150px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
  margin-top: -100%;
 height: 55px;
margin-left: 42%;

}

.button1 span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button1 span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button1:hover span {
  padding-right: 25px;
}

.button1:hover span:after {
  opacity: 1;
  right: 0;
}


      </style>
     
</head>
<body style="background-color: #b2b2b2;">
 <div class="jumbotron" style="height:10px;">
                <h2 style="margin-left:40%" >Step1:Create your test!</h2>
<form style="margin-left:37%;">
    
        
  <div class="form-group">
    <label for="exampleFormControlInput1" style="margin-top: 10%;">Title:</label>
    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="like Aptitude Test Part-1" style="margin-left:4%;width: 26%;color:rgb(196, 192, 192);width: 26%;">
  </div>
 <br>
  
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Description:</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" style="margin-left: 4%;
width: 60%;" placeholder=""></textarea>
  </div>
  <br>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Keywords:</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" style="margin-left:5%;width: 60%;" placeholder=""></textarea>
   
  </div>
</form>
<br>
<div class="container">
<div class="row">
    <div class="col-md-6">
        <a href="index.php" class="float-right"><button class="button1"><span>Back </span></button></a>
    </div>
    <div class="col-md-6">
        <a href="addquestion.html" class="float-left"><button class="button1"><span>Next </span></button></a>
    </div>
</div>
</div>
 
 
 
</body>
</html>