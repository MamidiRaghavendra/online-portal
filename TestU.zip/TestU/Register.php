<?php session_start();


 
// Include config file
$servername = "localhost";
$username = "id9726315_wp_505fb1e6e052602351622245fd40f636";
$password = "raghavendra";
$dbname = "id9726315_wp_505fb1e6e052602351622245fd40f636";

 // Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$email=$_REQUEST['email'];
$password1=$_REQUEST['psw'];

$query = "SELECT * FROM Registration WHERE email='$email' AND password='$password1'";
$result = mysqli_query($conn, $query);


if (mysqli_num_rows($result) > 0) {
    // output data of each row
   echo "HI,welcome to TestU.com<br>Your'e Succesfully login in!";
   
// Storing session data
$_SESSION["email"] = "$email";


// Redirect browser 
//header("Location: https://raghavendramamidi1.000webhostapp.com/TestU/TestU/index.php"); 
  //exit; 

echo '<script type="text/javascript">
           window.location = "./index.php"
      </script>';

} else {
    echo "Sorry Your'e not login in plese register!!";
}

mysqli_close($conn);
 

?>