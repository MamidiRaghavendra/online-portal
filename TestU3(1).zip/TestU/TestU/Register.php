<?php

$email=$_REQUEST['email'];
$password1=$_REQUEST['psw'];

$servername = "localhost";
$username = "id9726315_wp_505fb1e6e052602351622245fd40f636";
$password = "raghavendra";
$dbname = "id9726315_wp_505fb1e6e052602351622245fd40f636";

//create connection
$conn= mysqli_connect($servername,$username,$password,$dbname);
//check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql="INSERT INTO Registration(email,password)
VALUES ('$email','$password1')";





if (mysqli_query($conn,$sql)){
echo  include "succesfulregistermsg.html"; 
}else{
echo "Error:" .$sql. "<br>" . mysqli_error($error);
}
mysqli_close($conn);



?>



